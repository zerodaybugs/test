#!/usr/bin/env python3
from __future__ import annotations
import collections, hashlib, json, time
from pathlib import Path
from typing import Any
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

O=Path("r28_results");O.mkdir(exist_ok=True)
S=int("a3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50",16)
Z="0x"+"00"*20
N={
"ethereum":(1,"0xafDb696b693F38996B4fa7B839f3E9CfdD758694","0x15f7f910e5a8c86e609fd11c58f7342d86d3a25c",["https://ethereum-rpc.publicnode.com","https://rpc.flashbots.net","https://eth.llamarpc.com","https://1rpc.io/eth"]),
"optimism":(10,"0xeEE5205D35747307c3650c82b86Acfd1Abc300b0","0xE1CacE40A81C6d3616C6D79d9c88722c6A1d74b7",["https://optimism-rpc.publicnode.com","https://optimism.llamarpc.com","https://mainnet.optimism.io"]),
"bnb":(56,"0x696b456c1c79416CCE302D09e935b3cB80d0CDC5","0x50006F2C5C914cEF560ceeD7686f038480199202",["https://bsc-rpc.publicnode.com","https://binance.llamarpc.com","https://bsc-dataseed.binance.org"]),
"polygon":(137,"0x03441c89e7B751bb570f9Dc8C92702b127c52C51","0x89312A38457e4A1B1b25B6Fd6EA211610cae88EC",["https://polygon-bor-rpc.publicnode.com","https://polygon.llamarpc.com","https://polygon-rpc.com"]),
"base":(8453,"0x29Eceb50C5C1cc52FAb72Ff258B5a46324693BE7","0x1D011f972300E98738417A3AF1ED07731BBECcb2",["https://base-rpc.publicnode.com","https://base.llamarpc.com","https://mainnet.base.org"]),
"arbitrum":(42161,"0xE9700FD4194722eb680C57ed3e07C8Bb1933Bb98","0xB03DDF2CE1D32f2d1ee6d0e4fFBD76669633e5C5",["https://arb1.arbitrum.io/rpc","https://arbitrum.llamarpc.com","https://arbitrum-one-rpc.publicnode.com"])
}
BA=[{"type":"function","name":"implementation","stateMutability":"view","inputs":[],"outputs":[{"type":"address"}]}]
VA=[{"type":"function","name":x,"stateMutability":"view","inputs":[],"outputs":[{"type":t}]} for x,t in [
("asset","address"),("vaultFactory","address"),("connectorRegistry","address"),("feeDispatcher","address"),("totalAssets","uint256"),("totalSupply","uint256")]]

def H(x:bytes)->str:return hashlib.sha256(x).hexdigest()
def C(x):
    try:return Web3.to_checksum_address(x)
    except:return None
def W(x:bytes):
    return C("0x"+x[-20:].hex()) if len(x)==32 and int.from_bytes(x,"big") else None
def call(fn,b):
    try:return {"ok":True,"value":fn.call(block_identifier=b)}
    except Exception as e:return {"ok":False,"error":f"{type(e).__name__}: {e}"}
def strip(c):
    if len(c)>3:
        n=int.from_bytes(c[-2:],"big");s=len(c)-n-2
        if 0<=s<len(c)-2 and 0<n<=2048 and 0xa0<=c[s]<=0xbf:return c[:s],n+2
    return c,0
def ana(c):
    q,m=strip(c);sk=bytearray();zp=bytearray();p4=set();hist=collections.Counter();j=0;i=0;bad=False
    while i<len(q):
        op=q[i];i+=1;sk.append(op);zp.append(op);hist[f"{op:02x}"]+=1;j+=op==0x5b
        if 0x60<=op<=0x7f:
            n=op-0x5f;v=q[i:i+n]
            if len(v)!=n:bad=True;break
            if op==0x63:p4.add("0x"+v.hex())
            zp.extend(b"\0"*n);i+=n
    return {"raw_bytes":len(c),"stripped_bytes":len(q),"metadata_bytes_removed":m,
    "raw_sha256":H(c),"stripped_sha256":H(q),"opcode_skeleton_sha256":H(bytes(sk)),
    "zeroed_pushes_sha256":H(bytes(zp)),"opcode_count":len(sk),"jumpdest_count":j,
    "push4_values":sorted(p4),"opcode_histogram":dict(sorted(hist.items())),"malformed_push":bad}
def clients(net,cfg):
    cid,_,_,urls=cfg;out=[];errs=[]
    for u in urls:
        try:
            w=Web3(Web3.HTTPProvider(u,request_kwargs={"timeout":25}))
            if net in {"bnb","polygon"}:w.middleware_onion.inject(ExtraDataToPOAMiddleware,layer=0)
            if not w.is_connected() or w.eth.chain_id!=cid:raise RuntimeError("chain mismatch")
            out.append((w,u,int(w.eth.block_number)))
            if len(out)==2:return out
        except Exception as e:errs.append(f"{u}: {type(e).__name__}: {e}")
    raise RuntimeError("two RPC quorum unavailable | "+" | ".join(errs))
def inspect(w,net,cfg,b):
    cid,v,exp,_=cfg;v=C(v);bh=w.eth.get_block(b)["hash"].hex()
    pc=bytes(w.eth.get_code(v,block_identifier=b));word=bytes(w.eth.get_storage_at(v,S,block_identifier=b));be=W(word)
    if not be:raise RuntimeError("beacon slot empty")
    bc=w.eth.contract(be,abi=BA);ir=call(bc.functions.implementation(),b);im=C(ir.get("value")) if ir.get("ok") else None
    if not im:raise RuntimeError(f"implementation unresolved {ir}")
    bic=bytes(w.eth.get_code(be,block_identifier=b));ic=bytes(w.eth.get_code(im,block_identifier=b))
    if not ic:raise RuntimeError("implementation code empty")
    vc=w.eth.contract(v,abi=VA)
    getters={x:call(getattr(vc.functions,x)(),b) for x in ["asset","vaultFactory","connectorRegistry","feeDispatcher","totalAssets","totalSupply"]}
    direct=w.eth.contract(im,abi=[x for x in VA if x["name"] in {"vaultFactory","feeDispatcher"}])
    dg={x:call(getattr(direct.functions,x)(),b) for x in ["vaultFactory","feeDispatcher"]}
    return {"network":net,"chain_id":cid,"block":b,"block_hash":bh,"representative_vault":v,
    "expected_beacon":C(exp),"beacon_from_slot":be,"expected_beacon_match":be.lower()==exp.lower(),
    "active_implementation":im,"proxy_code_sha256":H(pc),"beacon_code_sha256":H(bic),
    "implementation_runtime":ana(ic),"proxy_getters":getters,"direct_implementation_getters":dg}
def quorum(a,b):
    checks={x:a[x]==b[x] for x in ["block_hash","beacon_from_slot","active_implementation","proxy_code_sha256","beacon_code_sha256"]}
    for x in ["raw_sha256","stripped_sha256","opcode_skeleton_sha256","zeroed_pushes_sha256"]:
        checks["implementation_"+x]=a["implementation_runtime"][x]==b["implementation_runtime"][x]
    return {"checks":checks,"all_match":all(checks.values())}
def pairs(rows):
    out=[]
    for i,a in enumerate(rows):
        for b in rows[i+1:]:
            x=a["primary"]["implementation_runtime"];y=b["primary"]["implementation_runtime"];xs=set(x["push4_values"]);ys=set(y["push4_values"])
            out.append({"left":a["network"],"right":b["network"],"raw_equal":x["raw_sha256"]==y["raw_sha256"],
            "stripped_equal":x["stripped_sha256"]==y["stripped_sha256"],
            "opcode_skeleton_equal":x["opcode_skeleton_sha256"]==y["opcode_skeleton_sha256"],
            "zeroed_pushes_equal":x["zeroed_pushes_sha256"]==y["zeroed_pushes_sha256"],
            "left_only_push4":sorted(xs-ys),"right_only_push4":sorted(ys-xs),
            "stripped_size_delta":x["stripped_bytes"]-y["stripped_bytes"],
            "opcode_count_delta":x["opcode_count"]-y["opcode_count"],
            "jumpdest_count_delta":x["jumpdest_count"]-y["jumpdest_count"]})
    return out
def main():
    rows=[];errs=[]
    for net,cfg in N.items():
        try:
            cs=clients(net,cfg);b=max(1,min(x[2] for x in cs)-5);a=inspect(cs[0][0],net,cfg,b);z=inspect(cs[1][0],net,cfg,b);q=quorum(a,z)
            if not q["all_match"]:raise RuntimeError(f"RPC mismatch {q}")
            rows.append({"network":net,"rpc_urls":[cs[0][1],cs[1][1]],"latest_heights":[cs[0][2],cs[1][2]],"primary":a,"secondary":z,"quorum":q})
        except Exception as e:errs.append({"network":net,"error":f"{type(e).__name__}: {e}"})
    pg=pairs(rows);sg=collections.defaultdict(list);zg=collections.defaultdict(list);rg=collections.defaultdict(list)
    for r in rows:
        x=r["primary"]["implementation_runtime"];sg[x["opcode_skeleton_sha256"]].append(r["network"]);zg[x["zeroed_pushes_sha256"]].append(r["network"]);rg[x["stripped_sha256"]].append(r["network"])
    complete=len(rows)==len(N) and not errs;div=len(sg)>1 or len(zg)>1
    decision="INCONCLUSIVE_NETWORK_OR_QUORUM_FAILURE" if not complete else ("HOLD_CROSSCHAIN_LOGIC_DIVERGENCE_REQUIRES_SEMANTIC_DIFF" if div else "KILL_CROSSCHAIN_RUNTIME_LOGIC_EQUIVALENT")
    ev={"schema":"kiln-r28-crosschain-missed-fix-v1","generated_at_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
    "safety":{"read_only":True,"rpc_methods":["eth_chainId","eth_blockNumber","eth_getBlockByNumber","eth_getStorageAt","eth_getCode","eth_call"],
    "public_chain_state_changes":0,"transactions_signed":0,"transactions_sent":0,"private_keys_loaded":0},
    "rows":rows,"errors":errs,"pairwise":pg,"groups":{"stripped_runtime":dict(rg),"opcode_skeleton":dict(sg),"zeroed_pushes":dict(zg)},
    "summary":{"network_scope":len(N),"network_inspected":len(rows),"error_count":len(errs),"complete":complete,"logic_divergence":div,"candidate_count":int(complete and div),"decision":decision}}
    (O/"EVIDENCE.json").write_text(json.dumps(ev,indent=2,sort_keys=True))
    gate={"schema":"kiln-r28-public-gate-v1","decision":decision,"submit_ready":False,"validated_critical":0,"validated_high":0,
    "candidate_count":int(complete and div),"network_scope":len(N),"network_inspected":len(rows),"error_count":len(errs),"logic_divergence":div,
    "opcode_skeleton_group_count":len(sg),"zeroed_push_group_count":len(zg),"public_chain_state_changes":0,"transactions_signed":0,"transactions_sent":0}
    (O/"PUBLIC_GATE.json").write_text(json.dumps(gate,indent=2,sort_keys=True))
    fs=sorted(p for p in O.iterdir() if p.is_file() and p.name!="SHA256SUMS.txt")
    (O/"SHA256SUMS.txt").write_text("".join(f"{H(p.read_bytes())}  {p.name}\n" for p in fs))
    print(json.dumps(gate,sort_keys=True));return 0 if complete else 2
if __name__=="__main__":raise SystemExit(main())
